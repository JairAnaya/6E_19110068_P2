"""
Jair Shiblón Anaya Rodríguez
19110068
6E6
Sistemas Expertos
Proyecto
"""
from tkinter import*
from tkinter import ttk
import cv2
import os

cont = 0 #Contador para puntaje de sección de morfología
cont2 = 0 #Contador para puntaje de sección de repetición de palabras

raiz=Tk()
raiz.title("Tamiz de problemas del lenguaje - TPL")
raiz.iconbitmap("icono.ico")

introFrame=Frame(raiz)
introFrame.pack()
tituloLabel=Label(introFrame, text="Tamiz de problemas del lenguaje - TPL", font=(20))
tituloLabel.pack()
tituloLabel.config(justify="center")
introLabel=Label(introFrame, text="Se utiliza para identificar trastornos o retrasos expresivos o bien, receptivo-expresivos del lenguaje")
introLabel.pack()
introLabel.config(justify="center")
intro2Label=Label(introFrame, text="La prueba TPL está dividida en dos secciones. La primera trata sore la tarea de morfología y la segunda sobre repetición de oraciones.")
intro2Label.pack()
intro2Label.config(justify="center")
intro3Label=Label(introFrame, text="La prueba se realiza a niños mexicanos monolingües en los siguientes rangos de edad:")
intro3Label.pack()
intro3Label.config(justify="center")

infoLabel=Label(introFrame, text="3 años - 3 años con 5 meses")
infoLabel.pack()
info2Label=Label(introFrame, text="3 años con 6 meses - 3 años con 11 meses")
info2Label.pack()
info3Label=Label(introFrame, text="4 años - 4 años con 5 meses")
info3Label.pack()
info4Label=Label(introFrame, text="4 años con 6 meses - 4 años con 11 meses")
info4Label.pack()
info5Label=Label(introFrame, text="5 años - 5 años con 11 meses")
info5Label.pack()
info6Label=Label(introFrame, text="6 años - 6 años con 11 meses")
info6Label.pack()
info7Label=Label(introFrame, text="Al escribir la edad se escribirá de la siguiente manera: por ejemplo, si el niño tiene 3 años con 5 meses, se escribirá 3 en la parte de edad y 5 en la parte de meses, si tiene 6 años con 11 meses, se escribirá 6 en la parte de edad y 11 en la parte de meses")
info7Label.pack()

def codBotonInfo():
    introFrame.destroy()
    datosFrame=Frame(raiz)
    datosFrame.pack()
    nombreLabel=Label(datosFrame, text="Nombre:")
    nombreLabel.grid(row=0, column=0, sticky="e")
    edadLabel=Label(datosFrame, text="Edad:")
    edadLabel.grid(row=1, column=0, sticky="e")
    mesesLabel=Label(datosFrame, text="Meses:")
    mesesLabel.grid(row=1, column=2, sticky="e")
    fechaLabel=Label(datosFrame, text="Fecha:")
    fechaLabel.grid(row=2, column=0, sticky="e")
    lugarLabel=Label(datosFrame, text="Lugar:")
    lugarLabel.grid(row=4, column=0, sticky="e")
    diaLabel=Label(datosFrame, text="00")
    diaLabel.grid(row=3, column=1)
    mesLabel=Label(datosFrame, text="00")
    mesLabel.grid(row=3, column=2)
    anhoLabel=Label(datosFrame, text="0000")
    anhoLabel.grid(row=3, column=3)
    cuadroNombre=Entry(datosFrame)
    cuadroNombre.grid(row=0, column=1)
    cuadroEdad=Entry(datosFrame)
    cuadroEdad.grid(row=1, column=1)
    cuadroMeses=Entry(datosFrame)
    cuadroMeses.grid(row=1, column=3)
    cuadroDia=Entry(datosFrame)
    cuadroDia.grid(row=2, column=1)
    cuadroMes=Entry(datosFrame)
    cuadroMes.grid(row=2, column=2)
    cuadroAnho=Entry(datosFrame)
    cuadroAnho.grid(row=2, column=3)
    cuadroLugar=Entry(datosFrame)
    cuadroLugar.grid(row=4, column=1)
    global nombre
    global edad
    global meses
    global edadRango
    global mesesRango
    global dia
    global mes
    global anho
    global lugar
    def codBotonComenzar():
        botonCom.destroy()
        datosFrame.destroy()
        morfoFrame=Frame(raiz)
        morfoFrame.pack()
        morfoLabel=Label(morfoFrame, text="MORFOLOGÍA", font=(18))
        morfoLabel.pack()
        infoMorfo=Label(morfoFrame, text="En esta primera sección se evaluará la parte morfológica del lenguaje. La tarea de morfología contiene 13 reactivos (preguntas de respuesta cerrada) divididos en cuatro secciones.")
        infoMorfo.pack()
        info2Morfo=Label(morfoFrame, text="Éstas contienen los 4 tipos de partículas morfológicas que resultan ser las más vulnerables en español: artículos, clíticos, preposiciones y palabras reservadas.")
        info2Morfo.pack()
        def ejArtBoton():
            botonEjArt.destroy()
            morfoFrame.destroy()
            ejArtFrame=Frame(raiz)
            ejArtFrame.pack()
            artiLabel=Label(ejArtFrame, text="Sección A: Artículos", font=(18))
            artiLabel.pack()
            artiEjLabel=Label(ejArtFrame, text="Ejemplo", font=(18))
            artiEjLabel.pack()
            abeja=PhotoImage(file="1.png")
            imagen1=Label(ejArtFrame, image=abeja)
            imagen1.place(x=50, y=50)

        botonEjArt=Button(raiz, text="Siguiente", command=ejArtBoton)
        botonEjArt.pack()
        
    botonCom=Button(raiz, text="Comenzar", command=codBotonComenzar)
    botonCom.pack()
    
    
    
    

botonInfo=Button(introFrame, text="Siguiente", command=codBotonInfo)
botonInfo.pack()





raiz.mainloop()
